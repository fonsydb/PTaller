package com.sistemasdistr.basico.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {
    private Integer id;
    private String username;
    private String email;
    private String nombreUsuario;
    private String password;
    private String confirmPassword;
    private Integer roleId;
    private String roleName;
}